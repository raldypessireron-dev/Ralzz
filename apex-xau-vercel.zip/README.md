# APEX XAU/USD — Market Analysis Terminal (Vercel)

Chart **TradingView asli** untuk XAU/USD (OANDA) dengan indikator **RSI(14), MACD(12,26,9), MA50, MA200, Bollinger(20, 2.0)**, widget **Technical Analysis** real-time, dan **Analisa AI** (Claude) yang membuat rekomendasi entry / SL / TP / kesimpulan berdasarkan indikator + sentimen global.

API key Anthropic disimpan **di server (serverless function)**, jadi tidak pernah terlihat di browser dan tidak ada masalah CORS.

## Struktur file
```
apex-xau-vercel/
├── index.html        # Front-end: chart TradingView + UI + tombol analisa
├── api/
│   └── claude.js     # Serverless function (proxy ke Anthropic API + web search)
├── package.json
├── vercel.json
└── README.md
```
Pertahankan struktur folder ini (terutama `api/claude.js` di dalam folder `api`).

## Langkah deploy

### 1. Siapkan API key Anthropic
1. Buka https://console.anthropic.com → buat **API Key**.
2. Di Console, aktifkan **Web Search** (Settings → fitur tools), karena analisa memakai web search untuk harga & sentimen live.
3. Pastikan ada saldo/credit di akun.

### 2. Deploy ke Vercel
**Cara A — drag & drop / GitHub (paling mudah):**
1. Upload folder ini ke sebuah repo GitHub, lalu di https://vercel.com → **Add New → Project → Import** repo tersebut. (Atau pakai Vercel CLI: `npm i -g vercel`, lalu `vercel` di dalam folder.)
2. Saat import, biarkan setting default (Framework Preset: **Other**, tanpa build command).

### 3. Set Environment Variable (WAJIB)
Di Vercel → **Project → Settings → Environment Variables**, tambahkan:

| Name | Value |
|------|-------|
| `ANTHROPIC_API_KEY` | `sk-ant-...` (API key kamu) |

Pilih environment **Production** (dan Preview bila perlu), **Save**, lalu **Redeploy**.

### 4. Selesai
Buka URL Vercel kamu. Chart TradingView langsung tampil. Klik **⚡ Hasilkan Analisa** untuk membuat rekomendasi AI.

## Catatan
- **Hemat biaya:** analisa AI hanya jalan saat tombol diklik (1 panggilan API per klik), bukan otomatis tiap buka halaman.
- **Ganti model:** ubah `MODEL` di `api/claude.js` (mis. `claude-opus-4-8` untuk lebih kuat, atau `claude-haiku-4-5-20251001` untuk lebih murah/cepat).
- **MA50/MA200:** RSI/MACD/Bollinger sudah pakai default yang persis sesuai permintaan. Untuk MA, jika TradingView belum men-set panjang 50/200, klik indikator Moving Average di chart → Settings → Length.
- **Timezone:** chart di-set ke Asia/Tokyo (UTC+9). Ubah `timezone` di `index.html` bila perlu.
- **Bukan saran finansial.** Selalu konfirmasi di MT5 dan kelola risiko sendiri.

## Troubleshooting
- *"ANTHROPIC_API_KEY belum di-set"* → tambahkan env var lalu redeploy.
- *Error Web Search / 4xx* → aktifkan Web Search di Console Anthropic, cek API key & credit.
- *Function timeout* → web search + analisa kadang 15–40 dtk; `maxDuration` sudah di-set 60 dtk (limit plan Hobby Vercel).
